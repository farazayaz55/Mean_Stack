# Web-Assignment-04-Mean-Stack
This Project Consist of Complete Mean Stack Implementation.


## How To Run this Project

### MongoDB
For Mongo DB to be connected to Node-JS and Express Create a empty Database Name "Pakwheels" and inside make a collection "cardetails"
All the data will be Inserted Automatically one connection is successfull

### Node and Express
cd into "NodeJS" folder and run "nodemon index.js" connection with database will be made and express will be waiting for any api calls.

### Angular
cd into "Angular" folder and run "ng server --open" in terminal to run Angular project NOTE """"run node server first"""